/*******************************************************************************
 * Filename              :   LCD_Interface.h
 * Author                :   Mohamemd Waleed Gad
 * Origin Date           :   May 11, 2023
 * Version               :   1.0.0
 * Compiler              :   GCC ARM Embedded Toolchain
 * Target                :
 * Notes                 :   None
 **
 *******************************************************************************/
/************************ SOURCE REVISION LOG *********************************
 *
 *    Date    Version   Author             Description
 *  14/10/20   1.0.0   Mohamemd Waleed   Initial Release.
 *
 *******************************************************************************/
#ifndef LCD_INCLUDE_LCD_INTERFACE_H_
#define LCD_INCLUDE_LCD_INTERFACE_H_

typedef struct
{
    Pin_Config_t RS;
    Pin_Config_t E;
    Pin_Config_t D[4];
} LCD_PINS_t;

void LCD_voidSendCommand(uint8_t Local_u8Command);
void LCD_voidSendData(uint8_t Local_u8Data);
void LCD_voidInit(void);
void LCD_voidSendString(const char *Local_String);
void LCD_voidGoToXY(uint8_t Local_u8XPos, uint8_t Local_u8YPos);
void LCD_WriteSpecialChar(uint8_t *Local_u8Pattern, uint8_t Local_u8PatternNumber, uint8_t Local_u8XPos, uint8_t Local_u8YPos);
void LCD_VoidSendNumber(int32_t Local_S32Number);
void LCD_ShiftLeft(void);
void LCD_ShiftRight(void);

#endif /* LCD_INCLUDE_LCD_INTERFACE_H_ */
