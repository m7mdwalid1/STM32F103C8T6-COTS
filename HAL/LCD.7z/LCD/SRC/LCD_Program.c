/*******************************************************************************
 * Filename              :   LCD_Program.c
 * Author                :   Mohamemd Waleed Gad
 * Origin Date           :   May 11, 2023
 * Version               :   1.0.0
 * Compiler              :   GCC ARM Embedded Toolchain
 * Target                :
 * Notes                 :   None
 **
 *******************************************************************************/
/************************ SOURCE REVISION LOG *********************************
 *
 *    Date    Version   Author             Description
 *  14/10/20   1.0.0   Mohamemd Waleed   Initial Release.
 *
 *******************************************************************************/
#include <stdint.h>
#include "../../../LIB/BIT_MATH.h"
#include "../../../MCAL/GPIO/Include/GPIO_Interface.h"
#include "../../../MCAL/RCC/Include/RCC_Interface.h"
#include "../Include/LCD_Interface.h"
#include "../../../MCAL/SysTick/Include/SysTick_Interface.h"

static Pin_Config_t RS =
{
		.Port = PORTA,
		.PinNum = PIN11,
		.OutputMode = PushPull,
		.Mode=Output_10MHZ,
};

static Pin_Config_t E =
{
		.Port = PORTA,
		.PinNum = PIN8,
		.OutputMode = PushPull,
		.Mode=Output_10MHZ,
};
static Pin_Config_t D4 =
{
		.Port = PORTB,
		.PinNum = PIN15,
		.OutputMode = PushPull,
		.Mode=Output_10MHZ,
};
static Pin_Config_t D5 =
{
		.Port = PORTB,
		.PinNum = PIN14,
		.OutputMode = PushPull,
		.Mode=Output_10MHZ,
};
static Pin_Config_t D6 =
{
		.Port = PORTB,
		.PinNum = PIN13,
		.OutputMode = PushPull,
		.Mode=Output_10MHZ,
};
static Pin_Config_t D7 =
{
		.Port = PORTB,
		.PinNum = PIN12,
		.OutputMode = PushPull,
		.Mode=Output_10MHZ,
};

void LCD_voidInit(void)
{
	RCC_APB2EnableCLK(APB2_IOPA);
	RCC_APB2EnableCLK(APB2_IOPB);
	GPIO_u8PinInit(&RS);
	GPIO_u8PinInit(&E);
	GPIO_u8PinInit(&D4);
	GPIO_u8PinInit(&D5);
	GPIO_u8PinInit(&D6);
	GPIO_u8PinInit(&D7);
	/*Wait for more than 30 ms*/
	SysTick_Delay_ms(30);
	LCD_voidSendCommand(0x33);
	LCD_voidSendCommand(0x32);	/* Send for 4 bit initialization of LCD  */
	LCD_voidSendCommand(0x28);	/* 2 line, 5*7 matrix in 4-bit mode */
	LCD_voidSendCommand(0x0c);	/* Display on cursor off */
	LCD_voidSendCommand(0x06);	/* Increment cursor (shift cursor to right) */
	LCD_voidSendCommand(0x01);	/* Clear display screen */

}
void LCD_voidSendCommand(uint8_t Local_u8Command)
{
	uint8_t Counter=0 , Command_Reversed=0,Bit=0;
	for (Counter=0;Counter<8;Counter++)
	{
		Bit = GET_BIT(Local_u8Command,Counter);
		if(Bit==1)
			SET_BIT(Command_Reversed,(7-Counter));
		else if (Bit==0)
			CLR_BIT(Command_Reversed,(7-Counter));
	}
	/*set RS pin to low for command*/
	GPIO_u8SetPinValue(RS.Port, RS.PinNum, PinLow);

	/*send command to data pins*/
	GPIO_u8SetFourPortValue(PORTB, PIN12, (Command_Reversed & 0x0F));

	/*send enable pulse*/
	GPIO_u8SetPinValue(E.Port, E.PinNum, PinHigh);
	SysTick_Delay_ms(2);
	GPIO_u8SetPinValue(E.Port, E.PinNum, PinLow);

	SysTick_Delay_us(200);

	/*send command to data pins*/

	GPIO_u8SetFourPortValue(PORTB, PIN12, ((Command_Reversed >> 4) & 0x0F));
	/*send enable pulse*/
	GPIO_u8SetPinValue(E.Port, E.PinNum, PinHigh);
	SysTick_Delay_ms(2);
	GPIO_u8SetPinValue(E.Port, E.PinNum, PinLow);
}
void LCD_voidSendData(uint8_t Local_u8Data)
{

	uint8_t Counter=0 , Command_Reversed=0,Bit=0;
	for (Counter=0;Counter<8;Counter++)
	{
		Bit = GET_BIT(Local_u8Data,Counter);
		if(Bit==1)
			SET_BIT(Command_Reversed,(7-Counter));
		else if (Bit==0)
			CLR_BIT(Command_Reversed,(7-Counter));
	}
	/*set RS pin to low for command*/
	GPIO_u8SetPinValue(RS.Port, RS.PinNum, PinHigh);

	/*send Data to data pins*/
	GPIO_u8SetFourPortValue(PORTB, PIN12, (Command_Reversed & 0x0F));
	/*send enable pulse*/
	GPIO_u8SetPinValue(E.Port, E.PinNum, PinHigh);
	SysTick_Delay_ms(2);
	GPIO_u8SetPinValue(E.Port, E.PinNum, PinLow);

	/*send Data to data pins*/
	GPIO_u8SetFourPortValue(PORTB, PIN12, ((Command_Reversed >> 4) & 0x0F));
	/*send enable pulse*/
	GPIO_u8SetPinValue(E.Port, E.PinNum, PinHigh);
	SysTick_Delay_ms(2);
	GPIO_u8SetPinValue(E.Port, E.PinNum, PinLow);
}

void LCD_voidSendString(const char *Local_String);
void LCD_voidGoToXY(uint8_t Local_u8XPos, uint8_t Local_u8YPos);
void LCD_WriteSpecialChar(uint8_t *Local_u8Pattern, uint8_t Local_u8PatternNumber, uint8_t Local_u8XPos, uint8_t Local_u8YPos);
void LCD_VoidSendNumber(int32_t Local_S32Number);
void LCD_ShiftLeft(void);
void LCD_ShiftRight(void);
