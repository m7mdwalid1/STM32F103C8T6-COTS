/*******************************************************************************
* Filename              :   LCD_Private.h
* Author                :   Mohamemd Waleed Gad
* Origin Date           :   May 11, 2023
* Version               :   1.0.0
* Compiler              :   GCC ARM Embedded Toolchain
* Target                :   
* Notes                 :   None 
**
*******************************************************************************/
/************************ SOURCE REVISION LOG *********************************
*
*    Date    Version   Author             Description 
*  14/10/20   1.0.0   Mohamemd Waleed   Initial Release.
*
*******************************************************************************/
#ifndef LCD_INCLUDE_LCD_PRIVATE_H_
#define LCD_INCLUDE_LCD_PRIVATE_H_



#endif /* LCD_INCLUDE_LCD_PRIVATE_H_ */
